var app = angular.module('foodStoreApp', []);

app.controller('foodStoreController', function ($scope, $http) {
    $scope.credentials = { username: '', password: '' };
    $scope.isLoggedIn = false;
    $scope.role = '';
    $scope.foodItems = [];
    $scope.orders = [];
    $scope.newFood = {};
    $scope.errorMessage = '';
    $scope.selectedCategory = '';

    // Check if user session exists
    $scope.init = function () {
        const session = JSON.parse(localStorage.getItem('userSession'));
        if (session) {
            $scope.isLoggedIn = true;
            $scope.role = session.role;
            $scope.credentials.username = session.username;

            // Load data based on the user's role
            if ($scope.role === 'admin') {
                $scope.getOrders();
            } else {
                $scope.getFoodItems();
                $scope.getOrders();
            }
        }
    };

    $scope.login = function () {
        $http.post('/api/login', $scope.credentials).then(function (response) {
            if (response.data.success) {
                $scope.isLoggedIn = true;
                $scope.role = response.data.role;

                // Save session to localStorage
                localStorage.setItem('userSession', JSON.stringify({
                    username: $scope.credentials.username,
                    role: $scope.role,
                }));

                // Load data based on the user's role
                if ($scope.role === 'admin') {
                    $scope.getOrders();
                } else {
                    $scope.getFoodItems();
                    $scope.getOrders();
                }
            } else {
                $scope.errorMessage = response.data.message;
            }
        });
    };

    $scope.logout = function () {
        $scope.isLoggedIn = false;
        $scope.role = '';
        $scope.credentials = { username: '', password: '' };

        // Clear session from localStorage
        localStorage.removeItem('userSession');
    };

    // Initialize the application
    $scope.init();

    // Get food items
    $scope.getFoodItems = function () {
        $http.get('/api/foodItems').then(function (response) {
            $scope.foodItems = response.data;
        });
    };

    // Add food item (Admin only)
    $scope.addFoodItem = function () {
        $http.post('/api/add/foodItem', $scope.newFood).then(function (response) {
            alert(response.data.message);
            $scope.newFood = {};
        });
    };

    // Get orders
    $scope.getOrders = function () {
        $http.get('/api/order').then(function (response) {
            $scope.orders = response.data.filter(order => order.userID === $scope.credentials.username || $scope.role === 'admin');
        });
    };

    // Update order status (Admin only)
    $scope.updateOrder = function (order, status) {
        $http.put('/api/update/order/' + order.orderID, { status: status }).then(function (response) {
            alert(response.data.message);
            $scope.getOrders();
        });
    };

    // Order food (User only)
    $scope.orderFood = function (food) {
        const order = {
            orderID: 'O' + new Date().getTime(),
            userID: $scope.credentials.username,
            foodItemID: food.foodItemID,
            status: 'Pending',
            qty: food.quantity || 1,
            total: (food.quantity || 1) * food.price,
        };

        $http.post('/api/add/order', order).then(function (response) {
            alert(response.data.message);
        });
    };
});
