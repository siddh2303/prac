const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// MongoDB Connection
mongoose.connect('mongodb://0.0.0.0:27017/foodStore');

const conn = mongoose.connection;
conn.on('connected', () => {
    console.log('MongoDB Connected');
});

// Schemas
const foodItemSchema = mongoose.Schema({
    foodItemID: String,
    foodItemName: String,
    category: String,
    image: String,
    price: Number,
});

const orderSchema = mongoose.Schema({
    orderID: String,
    userID: String,
    foodItemID: String,
    status: String,
    qty: Number,
    total: Number,
});

const FoodItem = mongoose.model('FoodItem', foodItemSchema);
const Order = mongoose.model('Order', orderSchema);

// Static Users
const users = {
    admin: { password: 'admin', role: 'admin' },
    user: { password: 'user', role: 'user' },
    user2: { password: 'user', role: 'user' },
};

// Routes
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = users[username];
    if (user && user.password === password) {
        res.json({ success: true, role: user.role });
    } else {
        res.json({ success: false, message: 'Invalid credentials' });
    }
});

app.get('/api/foodItems', (req, res) => {
    FoodItem.find().then((data) => res.json(data));
});

app.post('/api/add/foodItem', (req, res) => {
    FoodItem.create(req.body).then(() => res.json({ message: 'Food Item Added' }));
});

app.get('/api/order', (req, res) => {
    Order.aggregate([
        {
            $lookup: {
                from: 'fooditems',
                localField: 'foodItemID',
                foreignField: 'foodItemID',
                as: 'foodDetails',
            },
        },
        { $unwind: '$foodDetails' },
    ]).then(data => res.json(data));
});

app.post('/api/add/order', (req, res) => {
    Order.create(req.body).then(() => res.json({ message: 'Order Placed' }));
});

app.put('/api/update/order/:orderID', (req, res) => {
    Order.updateOne({ orderID: req.params.orderID }, { $set: { status: req.body.status } })
        .then(() => res.json({ message: 'Order Status Updated' }));
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
