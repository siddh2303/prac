
# Food Store Application

## Prerequisites
- Node.js installed
- MongoDB running locally

## Steps to Run the Application

1. Navigate to the backend folder:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the server:
   ```bash
   node app.js
   ```

4. Open `frontend/index.html` in your browser to access the application.
        